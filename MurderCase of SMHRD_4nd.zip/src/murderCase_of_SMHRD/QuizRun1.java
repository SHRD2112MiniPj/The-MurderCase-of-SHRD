 
package murderCase_of_SMHRD;

class QuizRun1
{
	public int run()
	{

int sum = 1;		try{}catch(Exception e){
		}
return sum;	}

}