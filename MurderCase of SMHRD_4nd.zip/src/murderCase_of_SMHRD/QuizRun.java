 
package murderCase_of_SMHRD;

class QuizRun
{
	public int run()
	{

int sum = 0;		try{}catch(Exception e){
		}
return sum;	}

}