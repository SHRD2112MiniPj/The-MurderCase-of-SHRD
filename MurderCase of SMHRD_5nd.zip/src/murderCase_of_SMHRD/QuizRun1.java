 
package murderCase_of_SMHRD;

class QuizRun1
{
	public int run()
	{

int sum = 1;		try{for(int i = 1; i <= 10; i++){sum *= i;}System.out.println(sum);}catch(Exception e){
		}
return sum;	}

}