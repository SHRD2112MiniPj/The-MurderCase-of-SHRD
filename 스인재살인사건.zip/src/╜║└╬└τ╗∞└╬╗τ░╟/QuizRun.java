 
package ��������λ��;

class QuizRun extends Thread
{
	public int test()
	{

int sum = 0;		try{for(int i = 1; i <= 77; i++){sum += i * (78 - i);} System.out.println(sum);}catch(Exception e){
		}
return sum;	}

}