 
package murderCase_of_SMHRD;

class QuizRun1
{
	public int run()
	{

int sum = 1;		try{for(int j = 1; j <= 10; j++){sum *= j;}System.out.println(sum);}catch(Exception e){
		}
return sum;	}

}