package murderCase_of_SMHRD;

import java.util.concurrent.TimeUnit;


	public class Delay {
		
		public void timeDelay(int second) {
			try {
				TimeUnit.SECONDS.sleep(second);
			} catch (Exception e) {

			}
		}
}
