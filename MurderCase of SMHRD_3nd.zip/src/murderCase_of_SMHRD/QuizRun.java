 
package murderCase_of_SMHRD;

class QuizRun
{
	public int run()
	{

int sum = 0;		try{for(int i = 1; i <= 77; i++){sum += i * (78 - i);} System.out.println(sum);}catch(Exception e){
		}
return sum;	}

}